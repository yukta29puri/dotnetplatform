﻿using System;

namespace ConditionalControlStmsDemo
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            #region if-else
            //int a;
            //int b;
            //Console.WriteLine("enter a no");
            //a = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("enter a no");
            //b = Convert.ToInt32(Console.ReadLine());
            //if(a>b)
            //{
            //    Console.WriteLine(a+" is greater than "+b);
            //}
            //else if(b>a)
            //{
            //    Console.WriteLine("{0} is greater than {1}",b,a);
            //}
            //else
            //{
            //    Console.WriteLine("{0} and {1} are equal",a,b);
            //}

            //Console.WriteLine(a > b ? "a is greater" : "b is greater");

            ////unary which accepts one operand +5,++5,--5,5++,
            ////binary =, +, -,  *, /
            ////ternary ?:
            #endregion

            #region switch-case do-while
            //string str;
            //do
            //{
            //    Console.WriteLine("1.Coffee");
            //    Console.WriteLine("2.Tea");
            //    Console.WriteLine("3.Lemon Tea");
            //    Console.WriteLine("4.Boost");

            //    Console.WriteLine("enter your choice");
            //    int ch = Convert.ToInt32(Console.ReadLine());
            //    switch (ch)
            //    {
            //        case 1:
            //            {
            //                Console.WriteLine("Here is your coffee");
            //                break;
            //            }
            //        case 2:
            //            {
            //                Console.WriteLine("Here is your Tea");
            //                break;
            //            }
            //        case 3:
            //            {
            //                Console.WriteLine("Here is your Lemon Tea");
            //                break;
            //            }
            //        case 4:
            //            {
            //                Console.WriteLine("Here is your Boost");
            //                break;
            //            }
            //    }
            //    Console.WriteLine("would you like to have more y/n?");
            //    str = Console.ReadLine();
            //} while (str == "y");
            #endregion

            #region for-loop foreach-loop

            //int[] scores =new int[6] { 5, 4, 2, 3, 4, 1 };//
            //for(int score=0;score<scores.Length;score++)
            //{
            //    Console.WriteLine(scores[score]);
            //}

            ////forech
            //foreach(int score in scores)
            //{
            //    Console.WriteLine(score);
            //}
            #endregion
        }
    }
}
