﻿using System;

namespace DataTypesDemo
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            int a;
            int b;
            int sum;
            Console.WriteLine("enter a no");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter another no");
            b = Convert.ToInt32(Console.ReadLine());
            sum = a + b;
            Console.WriteLine("The sum is:"+sum);


        }
    }
}
