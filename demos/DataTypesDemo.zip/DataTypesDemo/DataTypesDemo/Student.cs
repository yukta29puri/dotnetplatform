﻿using System;
namespace DataTypesDemo
{
    public struct Student
    {
    }
}
