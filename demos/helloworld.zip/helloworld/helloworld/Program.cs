﻿using System;//
namespace Test
{
        class TestClass
        {
        public static void Main()
        {

            Console.WriteLine("Hello World!");
        }
    }
}
