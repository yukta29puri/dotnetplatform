﻿using System;

namespace OopsConcepts
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Employee employee = new Employee(1234, "raj", "kumar", "manager", "male", "raj@google.com");
            employee.Display();
        }
    }
}
