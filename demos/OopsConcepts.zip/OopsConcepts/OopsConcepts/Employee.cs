﻿using System;
class Employee//PascalCase
{
    ////Fields
    //private int id;//camelCase
    //private string firstName;
    ////private string lastName;
    //private string designation;
    //private string gender;
    //private string email;

    ////Properties
    //public int Id
    //{
    //    get { return id; }
    //    set { id = value; }
    //}

    //public string FirstName {
    //    get => firstName; set => firstName = value;
    //}

    //auto implemented property
    //public int Id { get; set; }//is same as
    private int id;
    public int Id
    {
        get { return id; }
        set { id = value; }
    }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Designation { get; set; }
    public string Gender { get; set; }
    public string Email { get; set; }

    //Constructor
    public Employee(int id,string firstName,string lastName,string designation,string gender,string email)
    {
        Id = id;
        FirstName = firstName;
        LastName = lastName;
        Designation = designation;
        Gender = gender;
        Email = email;
    }



    //Methods
    public void Display()//PascalCase
    {
        Console.WriteLine("Employee Info:");
        Console.WriteLine("Id:{0} FirstName:{1} LastName:{2} Designation:{3} Gender:{4} Email:{5}",
            Id,FirstName,LastName,Designation,Gender,Email);
    }

    public int CalculateSalary()
    {
        return 0;
    }

    public void SwipeIn()
    {

    }
    public void SwipeOut()
    {

    }

}